﻿namespace SocialMediaiOS
{
    public class SightingsCategory
    {
        public string Id { get; set; }
        public string Description { get; set; }
    }
}
