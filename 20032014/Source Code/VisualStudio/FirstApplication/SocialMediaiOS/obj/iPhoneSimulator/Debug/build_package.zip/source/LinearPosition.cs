﻿namespace SocialMediaiOS
{
    public class LinearPosition
    {
        public int XPosition { get; set; }
        public int YPosition { get; set; }
    }
}